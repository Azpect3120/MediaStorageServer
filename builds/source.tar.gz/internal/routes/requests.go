package routes

type CreateFolderRequest struct {
	Name string `json:"name"`
}
