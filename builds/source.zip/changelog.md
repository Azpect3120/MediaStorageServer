## Version 1.0.0 Release

Version release: 11/29/2023

### Notes

The first production version has been released! Many of the bugs have been tested but its not 100% bug free.

As bugs are noticed they will be fixed.

Basic functionality is complete, images and videos are stored, cached, and duplicates are used to save disk storage.

Inputs are validated but has been tested extensively.
